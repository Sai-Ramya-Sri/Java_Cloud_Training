import java.util.Scanner;
class Add{
	
	static int add(int a, int b)
	{
		return a+b;
	}
	
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter 2 numbers:");
        int a = sc.nextInt();
        int b = sc.nextInt();
        System.out.println("Sum of "+a+" and "+b+" is "+add(a,b));
        sc.close();
     }
}