import java.util.*;

class Employee_information{
	
	private String empID, Employee_name, employee_designation, employee_comm;
	private double Employee_salary;
	
	public Employee_information(String id, String n, String d, double s, String c)
	{
		this.empID = id;
		this.Employee_name = n;
		this.employee_designation = d;
		this.Employee_salary = s;
		this.employee_comm = c;
	}
	
	public String getEmpID() {
		return empID;
	}
	public void setEmpID(String empID) {
		this.empID = empID;
	}
	public String getEmployee_name() {
		return Employee_name;
	}
	public void setEmployee_name(String employee_name) {
		Employee_name = employee_name;
	}
	public String getEmployee_designation() {
		return employee_designation;
	}
	public void setEmployee_designation(String employee_designation) {
		this.employee_designation = employee_designation;
	}
	public String getEmployee_comm() {
		return employee_comm;
	}
	public void setEmployee_comm(String employee_comm) {
		this.employee_comm = employee_comm;
	}
	public double getEmployee_salary() {
		return Employee_salary;
	}
	public void setEmployee_salary(double employee_salary) {
		Employee_salary = employee_salary;
	}
	
	public void display()
	{
		System.out.println("Employee_Information [ID: "+this.empID+", Name: "+this.Employee_name+", Designation: "+this.employee_designation+", Salary: "+this.Employee_salary+", Employee Comm: "+this.employee_comm+"]");
	}
}

class MMASaving_Account{
	
	private String accountID, accountholder_name;
	private double account_balance;
	private boolean isSalaryAccount;
	
	public MMASaving_Account(String id, String n, double b, boolean is)
	{
		this.accountID = id;
		this.accountholder_name = n;
		this.account_balance = b;
		this.isSalaryAccount = is;
	}
	
	public String getAccountID() {
		return accountID;
	}
	public void setAccountID(String accountID) {
		this.accountID = accountID;
	}
	public String getAccountholder_name() {
		return accountholder_name;
	}
	public void setAccountholder_name(String accountholder_name) {
		this.accountholder_name = accountholder_name;
	}
	public double getAccount_balance() {
		return account_balance;
	}
	public void setAccount_balance(double account_balance) {
		this.account_balance = account_balance;
	}
	public boolean isSalaryAccount() {
		return isSalaryAccount;
	}
	public void setSalaryAccount(boolean isSalaryAccount) {
		this.isSalaryAccount = isSalaryAccount;
	}
	public void display()
	{
		System.out.println("MMASaving_Account [Account ID: "+this.accountID+", Account Holder Name: "+this.accountholder_name+", Account Balance: "+this.account_balance+", Salary Account: "+this.isSalaryAccount+"]");
	}
}

public class Employee_3 {
	
	public static void main(String[] args)
	{
		
		Scanner sc = new Scanner(System.in);
		
		Employee_information e1 = new Employee_information("1","Name1","D1",4846843,"C1");
		MMASaving_Account a1 = new MMASaving_Account("ID1","Name1",868464,true);
		
		Employee_information e2 = new Employee_information("2","Name2","D2",3148645,"C2");
		MMASaving_Account a2 = new MMASaving_Account("ID2","Name2",3665410,false);
		
		Employee_information e3 = new Employee_information("3","Name3","D3",218454,"C3");
		MMASaving_Account a3 = new MMASaving_Account("ID3","Name3",328570,true);
		
		Employee_information e4 = new Employee_information("4","Name4","D4",897123,"C4");
		MMASaving_Account a4 = new MMASaving_Account("ID4","Name4",978321,true);
		
		Employee_information e5 = new Employee_information("5","Name5","D5",1249654,"C5");
		MMASaving_Account a5 = new MMASaving_Account("ID5","Name5",5418714,false);
		
		Employee_information e6 = new Employee_information("6","Name6","D6",6874525,"C6");
		MMASaving_Account a6 = new MMASaving_Account("ID6","Name6",7156452,false);
		
		LinkedHashMap<Employee_information, MMASaving_Account> hm = new LinkedHashMap<>();
		
		hm.put(e1, a1);
		hm.put(e2, a2);
		hm.put(e3, a3);
		hm.put(e4, a4);
		hm.put(e5, a5);
		hm.put(e6, a6);
		
		for(Employee_information e:hm.keySet())
		{
			e.display();
			hm.get(e).display();
			System.out.println();
		}
		
		sc.close();
	}
}