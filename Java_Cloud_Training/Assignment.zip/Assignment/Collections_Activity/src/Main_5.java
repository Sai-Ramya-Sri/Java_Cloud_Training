import java.util.*;

class Laptop{
	
	String company, model, operatingSystem, processor;
	
	public Laptop(String company, String model, String operatingSystem, String processor) {
		this.company = company;
		this.model = model;
		this.operatingSystem = operatingSystem;
		this.processor = processor;
	}

	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((company == null) ? 0 : company.hashCode());
		result = prime * result + ((model == null) ? 0 : model.hashCode());
		return result;
	}

	public boolean equals(Laptop l) {
		return this.company.equals(l.company) && this.model.equals(l.model);
	}	
}

class Car{
	
	String make, model;
	int year;
	double price;

	public Car(String make, String model, int year, double price) {
		this.make = make;
		this.model = model;
		this.year = year;
		this.price = price;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((make == null) ? 0 : make.hashCode());
		result = prime * result + ((model == null) ? 0 : model.hashCode());
		return result;
	}

	public boolean equals(Car c) {
		return model.equals(c.model) && make.equals(c.make);
	}
}

class Television{
	
	String company, type;
	boolean Enable3D;
	double price;
	
	
	
	public Television(String company, String type, boolean enable3d, double price) {
		this.company = company;
		this.type = type;
		Enable3D = enable3d;
		this.price = price;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((company == null) ? 0 : company.hashCode());
		long temp;
		temp = Double.doubleToLongBits(price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Television other = (Television) obj;
		if (company == null) {
			if (other.company != null)
				return false;
		} else if (!company.equals(other.company))
			return false;
		if (Double.doubleToLongBits(price) != Double.doubleToLongBits(other.price))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}
}

class CellPhone{
	
	String company, model, description, operatingSystem;
	double price;
	
	
	
	public CellPhone(String company, String model, String description, String operatingSystem, double price) {
		this.company = company;
		this.model = model;
		this.description = description;
		this.operatingSystem = operatingSystem;
		this.price = price;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((company == null) ? 0 : company.hashCode());
		result = prime * result + ((model == null) ? 0 : model.hashCode());
		result = prime * result + ((operatingSystem == null) ? 0 : operatingSystem.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CellPhone other = (CellPhone) obj;
		if (company == null) {
			if (other.company != null)
				return false;
		} else if (!company.equals(other.company))
			return false;
		if (model == null) {
			if (other.model != null)
				return false;
		} else if (!model.equals(other.model))
			return false;
		if (operatingSystem == null) {
			if (other.operatingSystem != null)
				return false;
		} else if (!operatingSystem.equals(other.operatingSystem))
			return false;
		return true;
	}
}

class School{
	
	String name, city, school_district;
	int greatSchoolRanking;
	
	
	public School(String name, String city, String school_district, int greatSchoolRanking) {
		this.name = name;
		this.city = city;
		this.school_district = school_district;
		this.greatSchoolRanking = greatSchoolRanking;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((school_district == null) ? 0 : school_district.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		School other = (School) obj;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (school_district == null) {
			if (other.school_district != null)
				return false;
		} else if (!school_district.equals(other.school_district))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "School [name=" + name + ", city=" + city + ", school_district=" + school_district
				+ ", greatSchoolRanking=" + greatSchoolRanking + "]";
	}
	
	
}
public class Main_5 {

	public static void main(String[] args) {
		
		School s1 = new School("Name1", "City1", "District1", 1);
//		School s2 = new School("Name1", "City1", "District1", 1);

		
		LinkedHashSet<School> lhs = new LinkedHashSet<>();
		lhs.add(s1);
//		TreeSet<School> ts1 = new TreeSet<>();
//		ts1.add(s1);
//		System.out.println(lhs);
//		Car c1 = new Car("Make1", "Model1", 2018, 800000);
		//TreeSet<Car> ts2 = new TreeSet<>();
		//ts2.add(c1);
		
		String name="N1", fruit="F1";
		System.out.println(s1.toString());
		HashMap<String, String> m = new HashMap<>();
		m.put(name, fruit);
	}
}
