import java.util.*;
class Movie_Details implements Comparable<Movie_Details>{
	private String mov_Name, lead_actor, lead_actress, genre;
	public static int choice=8;
	
	public Movie_Details(String mov_Name, String lead_actor, String lead_actress, String genre) {
		this.mov_Name = mov_Name;
		this.lead_actor = lead_actor;
		this.lead_actress = lead_actress;
		this.genre = genre;
	}

	public String getMov_Name() {
		return mov_Name;
	}

	public void setMov_Name(String mov_Name) {
		this.mov_Name = mov_Name;
	}

	public String getLead_actor() {
		return lead_actor;
	}

	public void setLead_actor(String lead_actor) {
		this.lead_actor = lead_actor;
	}

	public String getLead_actress() {
		return lead_actress;
	}

	public void setLead_actress(String lead_actress) {
		this.lead_actress = lead_actress;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}
	
	public void display()
	{
		System.out.println("Movie Details :\nMovie Name : "+this.getMov_Name()+"\nLead Actor : "+this.getLead_actor()+"\nLead Actress : "+this.getLead_actress()+"\nGenre : "+this.getGenre());
	}
	
	public int compareTo(Movie_Details m)
	{
		if(choice==1)
			return this.getMov_Name().compareTo(m.getMov_Name());
		else if(choice==2)
			return getLead_actor().compareTo(m.getLead_actor());
		else if(choice==3)
			return getLead_actress().compareTo(m.getLead_actress());
		else
			return getGenre().compareTo(m.getGenre());
	}
}


public class Movie_DetailsList_2 {
	
	public static Set<Movie_Details> ml = new TreeSet<Movie_Details>();
	
	public void add_movie(String mov_Name, String lead_actor, String lead_actress, String genre)
	{
		ml.add(new Movie_Details(mov_Name, lead_actor, lead_actress, genre));
	}
	
	public void remove(String mov_Name)
	{
		for(Movie_Details m:ml)
		{
			if(m.getMov_Name().equals(mov_Name))
			{
				ml.remove(((List<Movie_Details>)ml).indexOf(m));
			}
		}
	}
	
	public void remove_AllMovies()
	{
		ml.removeAll(ml);
	}
	
	public void find_movie_By_mov_Name(String mn)
	{
		for(Movie_Details m:ml)
		{
			if(m.getMov_Name().equals(mn))
			{
				m.display();
			}
		}
	}
	
	public void find_movie_By_Genre(String g)
	{
		for(Movie_Details m:ml)
		{
			if(m.getGenre().equals(g))
			{
				m.display();
			}
		}
	}
	
	public void takeChoice(int c)
	{
		Movie_Details.choice = c;
	}
	
	public void show()
	{
		for(Movie_Details m:ml)
		{
			m.display();
			System.out.println();
		}
	}
	
	public static void main(String[] args) {
		
		Movie_DetailsList_2 ml1 = new Movie_DetailsList_2();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter choice to sort the list :\n1.Movie Name\n2.Lead Actor\n3.Lead Actress\n4.Genre");
		int ch = sc.nextInt();
		if(ch<1 || ch>4)
		{
			System.out.println("Invalid Input");
			System.exit(0);
		}
		ml1.takeChoice(ch);
		ch=1;
		String n,a1,a2,g;
		boolean t = true;
		while(t)
		{
			switch(ch)
			{
				case 1 : System.out.println("Enter Movie name, Lead actor, Lead actress, Genre : ");
						n = sc.next();
						a1 = sc.next();
						a2 = sc.next();
						g = sc.next();
						ml1.add_movie(n, a1, a2, g);
						System.out.println("Add another movie? (Y/N)");
						n = sc.next();
						if((n.equalsIgnoreCase("Y"))==true)
							t=true;
						else
							t=false;
						break;
				default : t = false;
			}
			
		}
		System.out.println("Movie Details : ");
		ml1.show();
	}
}