import java.util.*;

class Parked_CarOwner_Details{
	
	private String ownerName, carModel, carNo, ownerAddress;
	private long ownerMobileNo;
	
	public Parked_CarOwner_Details(String ownerName, String carModel, String carNo, long ownerMobileNo, String ownerAddress) {
		this.ownerName = ownerName;
		this.carModel = carModel;
		this.carNo = carNo;
		this.ownerAddress = ownerAddress;
		this.ownerMobileNo = ownerMobileNo;
	}

	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getCarModel() {
		return carModel;
	}
	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}
	public String getCarNo() {
		return carNo;
	}
	public void setCarNo(String carNo) {
		this.carNo = carNo;
	}
	public String getOwnerAddress() {
		return ownerAddress;
	}
	public void setOwnerAddress(String ownerAddress) {
		this.ownerAddress = ownerAddress;
	}
	public long getOwnerMobileNo() {
		return ownerMobileNo;
	}
	public void setOwnerMobileNo(long ownerMobileNo) {
		this.ownerMobileNo = ownerMobileNo;
	}
	
	public void display()
	{
		System.out.println("Parked_CarOwner_Details[Owner Name: "+this.ownerName+", Car Model: "+this.carModel+", Car Number: "+this.carNo+", OwnerMobileNo: "+this.ownerMobileNo+", Owner Address: "+this.ownerAddress+"]");
	}	
}

class Parked_CarOwnerList_4{
	
	static LinkedList<Parked_CarOwner_Details> l = new LinkedList<>();
	
	public static void add_new_car(Parked_CarOwner_Details d)
	{
		l.add(d);
	}
	
	public static void remove_car(int token)
	{
		System.out.println("Car removed");
		l.remove(token);
	}
	public static void get_parked_car_location(int token)
	{
		if(token>220 && token<=240)
		{
			System.out.println("Car is parked in Floor 3, Section 4");
		}
		else if(token>200)
			System.out.println("Car is parked in Floor 3, Section 3");
		else if(token>180)
			System.out.println("Car is parked in Floor 3, Section 2");
		else if(token>160)
			System.out.println("Car is parked in Floor 3, Section 1");
		else if(token>140)
			System.out.println("Car is parked in Floor 2, Section 4");
		else if(token>120)
			System.out.println("Car is parked in Floor 2, Section 3");
		else if(token>100)
			System.out.println("Car is parked in Floor 2, Section 2");
		else if(token>80)
			System.out.println("Car is parked in Floor 2, Section 1");
		else if(token>60)
			System.out.println("Car is parked in Floor 1, Section 4");
		else if(token>40)
			System.out.println("Car is parked in Floor 1, Section 3");
		else if(token>20)
			System.out.println("Car is parked in Floor 1, Section 2");
		else
			System.out.println("Car is parked in Floor 1, Section 1");	
	}
	
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		int ch,token;
		String n, m, cno, a;
		long ono;
		
		while(true)
		{
			System.out.println("Enter 1 to add car, 2 to remove car and 3 to view the list");
			ch = sc.nextInt();
			
			switch(ch)
			{
				case 1:System.out.println("Enter Car Owner's Details: \nOwer's Name, Car Model, Car Number, Ower's MobileNumber, Ower's Address: ");
						n = sc.next();
						m = sc.next();
						cno = sc.next();
						ono = sc.nextLong();
						a = sc.next();
						Parked_CarOwner_Details d = new Parked_CarOwner_Details(n,m,cno,ono,a);
						Parked_CarOwnerList_4.add_new_car(d);
						System.out.println("Car is parked at token number "+(l.indexOf(d)+1)+"\n");
						break;
				case 2:System.out.println("Enter token number: ");
						token = sc.nextInt();
						Parked_CarOwnerList_4.get_parked_car_location(token-1);
						System.out.println();
						Parked_CarOwnerList_4.remove_car(token-1);
				case 3:for(Parked_CarOwner_Details cd:l)
						{
							System.out.println("Token Number : "+(l.indexOf(cd)+1));
							cd.display();
							System.out.println();
						}
			}
		}
	}
}