import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CommonTest {

	@Test
	void test() {
		int l=2,m=5,n=4,max=5;
		int[] a = new int[]{0,23};
        int[] b = new int[] {0,5,6,23,89};
        int[] c = new int[] {0,2,8,23};
        int[] r = new int[max];
        int[] s = new int[] {2,0,23};
		r=Common.find(a,b,l,m,max);
		max=r[0];
        for(int i=0;i<max;i++)
        {
        	r[i]=r[i+1];
        }
        r=Common.find(r,c,max,n,max);
		assertArrayEquals(s,r);
	}

}
