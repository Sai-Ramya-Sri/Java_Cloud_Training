class Employee{
	long employeeId;
	String employeeName;
	String employeeAddress;
	long employeePhone;
	double basicSalary;
	double specialAllowance = 250.80;
	double hra = 1000.50;
	
	public Employee()
	{
		
	}
	public Employee(long Id, String Name, String address, long phone)
	{
		this.employeeId = Id;
		this.employeeName = Name;
		this.employeeAddress = address;
		this.employeePhone = phone;
	}
	
	public void calculateSalary()
	{
		double salary = basicSalary + (basicSalary*specialAllowance/100) + (basicSalary*hra/100);
		System.out.println("Salary : "+salary);
	}
	public void calculateTransportAllowance()
	{
		double transportAllowance = 10*this.basicSalary/100;
		System.out.println("Transport Allowance of Trainee : "+transportAllowance);
	}
}

class Manager extends Employee{
	public Manager()
	{
		
	}
	public Manager(long Id, String Name, String address, long phone, double salary)
	{
		super(Id,Name,address,phone);
		this.basicSalary = salary;
	}
	
	public void calculateTransportAllowance()
	{
		double transportAllowance = 15*this.basicSalary/100;
		System.out.println("Transport Allowance of Manager : "+transportAllowance);
	}
	
}

class Trainee extends Employee{
	
	public Trainee() {
		
	}
	public Trainee(long Id, String Name, String address, long phone, double salary)
	{
		super(Id,Name,address,phone);
		this.basicSalary = salary;
	}
}


public class InheritanceActivity {

	public static void main(String[] args) {
		
		Manager m1 = new Manager(126534,"Peter","Chennai India",237844,65000);
		m1.calculateSalary();
		
		Trainee t1 = new Trainee(29846,"Jack","Mumbai India",442085,45000);
		t1.calculateSalary();
		
		m1.calculateTransportAllowance();
		t1.calculateTransportAllowance();
	}

}
