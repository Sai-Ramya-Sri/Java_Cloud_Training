import java.util.*;
class AgeNotWithinRangeException extends Exception{
	public AgeNotWithinRangeException(String s) {
		super(s);
	}
}

class NameNotValidException extends Exception{
	public NameNotValidException(String s) {
		super(s);
	}
}

class Student{
	private int rollno;
	private String name;
	private int age;
	private String course;
	
	public Student(int rn, String n, int a, String c)
	{
		try {
			if(a<15 || a>21)
			{
				throw new AgeNotWithinRangeException("Age Not Within Range");
			}
			else if(n.matches("^[a-zA-Z]*$")==false) {
				throw new NameNotValidException("Name Not Valid");
			}
			else {
				this.rollno = rn;
				this.name = n;
				this.age = a;
				this.course = c;
				System.out.println("Valid");
			}
		}
		catch(AgeNotWithinRangeException age)
		{
			System.out.println(age.getMessage());
		}
		catch(NameNotValidException name)
		{
			System.out.println(name.getMessage());
		}
	}
}

public class Main_2_Student {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Roll Number, Name, Age and Course of a student");
		int r = sc.nextInt();
		String n = sc.next();
		int a = sc.nextInt();
		String c = sc.next();
		new Student(r,n,a,c);
		
		sc.close();
	}
}
