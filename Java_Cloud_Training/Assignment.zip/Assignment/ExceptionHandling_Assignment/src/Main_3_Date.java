class InvalidMonthException extends Exception{
	public InvalidMonthException(String s)
	{
		super(s);
	}
}

class InvalidDayException extends Exception{
	public InvalidDayException(String s)
	{
		super(s);
	}
}

class MyDate{
	
	private int day, month, year;
	private int[] days = new int[] {0,31,28,31,30,31,30,31,31,30,31,30,31};
	
	public MyDate() {
		
	}
	public MyDate(int d, int m, int y)
	{
		try {
				if(m<1 || m>12)
				{
					throw new InvalidMonthException("Invalid Month");
				}
				else if( d<1 || (m==2 && ((leap(y)==1 && d>29) || (leap(y)==0 && d>28))) || (m!=2 && day>days[m]) )
				{
					throw new InvalidDayException("Invalid Day");
				}
				else
				{
					this.day = d;
					this.month = m;
					this.year = y;
					System.out.println("Valid date");
				}
			}
		catch(InvalidMonthException me)
		{
			System.out.println(me.getMessage());
		}
		catch(InvalidDayException de)
		{
			System.out.println(de.getMessage());
		}
		
		this.day = d;
		this.month = m;
		this.year = y;
	}
	
	public int leap(int year)
	{
		if(( (year%4==0 && year%100!=0) || year%400==0))
			return 1;
		return 0;
	}
}

public class Main_3_Date {

	public static void main(String[] args) {
		
		for(int i=0;i<21;i+=3)
		{
			int d = Integer.parseInt(args[i+0]);
			int m = Integer.parseInt(args[i+1]);
			int y = Integer.parseInt(args[i+2]);
			System.out.print(d+"/"+m+"/"+y+" : ");
			new MyDate(d,m,y);	
		}
	}
}
