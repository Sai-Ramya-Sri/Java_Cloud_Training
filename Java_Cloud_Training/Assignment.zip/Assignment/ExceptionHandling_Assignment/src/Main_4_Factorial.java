import java.util.*;
class InvalidInputException extends Exception{
	public InvalidInputException(String s)
	{
		super(s);
	}
}
class FactorialException extends Exception{
	public FactorialException(String s)
	{
		super(s);
	}
}

class Factorial {
	
	
	public int getFactorial(int num)
	{
		try {
			if(num<2)
			{
				throw new InvalidInputException("Invalid Inpit");
			}
			else {
				int f = 1;
				for(int i=num;i>1;i--)
				{
					f*=i;
				}
				try {
					if(f==0) //factorial > Integer.MAX_VALUE
					{
						throw new FactorialException("Factorial value exceeded the highest value of int");
					}
					else {
							return f;
					}
				}
				catch(FactorialException fe)
				{
					System.out.println(fe.getMessage());
					return -1;
				}
			}
		}
		catch(InvalidInputException ie)
		{
			System.out.println(ie.getMessage());
			return -1;
		}
	}
}


public class Main_4_Factorial {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int n = sc.nextInt();
		Factorial f1 = new Factorial();
		int r = f1.getFactorial(n);
		if(r>-1)
			System.out.println("Factorial of "+n+" is "+r);
		sc.close();
	}
}
