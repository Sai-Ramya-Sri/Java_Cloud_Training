import java.util.*;

class StringTooLongException extends Exception{
	public StringTooLongException(String s)
	{
		super(s);
	}
}

class Main_6_String {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		while(s.equals("DONE")==false)
		{
			try {
				if(s.length()>19)
				{
					throw new StringTooLongException("String is Too Long");
				}
			}
			catch(StringTooLongException se)
			{
				System.out.println(se.getMessage());
				System.exit(0);
			}
			s = sc.next();
		}
		sc.close();
	}
}