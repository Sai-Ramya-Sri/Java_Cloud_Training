import java.util.*;

public class Main_7_Float {
	
	static int k=0;
	static float sum=0;
	
	public static void main(String[] args) {
		float n;
		while(k<2){
			try {
					Scanner sc = new Scanner(System.in);
					System.out.println("Enter a floating point number : ");
					n = sc.nextFloat();
					sum+=n;
			}
			catch(java.util.InputMismatchException e)
			{
				if(k==1)
				{
					k++;
					System.out.println("\n2 invalid input values");
					System.out.println("Sum is "+sum);
				}
				else {
					System.out.println("1 invalid input value\n");
					k++;
				}
			}
		}
	}
}
