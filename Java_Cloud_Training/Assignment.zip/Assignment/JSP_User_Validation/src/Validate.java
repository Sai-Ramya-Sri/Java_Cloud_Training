import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;


/**
 * Servlet implementation class Validate
 */
@WebServlet("/Validate")
public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	Users u = new Users();
	ArrayList<Users> l = u.get();
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Validate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name = request.getParameter("name");
		String pwd = request.getParameter("pwd");
		System.out.println(name);
		for(Users u:l)
		{
			if(u.uname.equals(name) && u.pwd.equals(pwd))
			{
				if(u.utype.equals("admin"))
				{
					response.sendRedirect("admin.jsp"); 
					return;
				}
				else if(u.utype.equals("user"))
				{
					response.sendRedirect("user.jsp");
					return;
				}
			}
		}
		response.sendRedirect("invalid.jsp");
		return;
	}

}

class Users{
	String uname, pwd, utype;
	
	public Users()
	{
		
	}
	public Users(String n, String p, String t)
	{
		this.uname=n;
		this.pwd=p;
		this.utype=t;
	}

	public String getUname() {
		return uname;
	}

	public String getPwd() {
		return pwd;
	}

	public String getUtype() {
		return utype;
	}
	public ArrayList<Users> get()
	{
		ArrayList<Users> l = new ArrayList<>();
		l.add(new Users("a","a","admin"));
		l.add(new Users("b","b","user"));
		l.add(new Users("c","c","user"));
		l.add(new Users("d","d","admin"));
		return l;
	}
}
