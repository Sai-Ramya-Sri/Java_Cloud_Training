import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
public class Calculate {

	public int sum(int a, int b)
	{
		System.out.println("Adding "+a+" and "+b);
		return a+b;
	}
}