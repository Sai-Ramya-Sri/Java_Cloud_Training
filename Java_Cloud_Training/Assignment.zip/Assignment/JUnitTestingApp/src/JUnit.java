import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class JUnit {

	public int sum(int a, int b)
	{
		System.out.println("Adding "+a+" and "+b);
		return a+b;
	}
	@Test
	void testAdd() {
		int x = sum(5,7);
		assertEquals(12,x);
	}

}