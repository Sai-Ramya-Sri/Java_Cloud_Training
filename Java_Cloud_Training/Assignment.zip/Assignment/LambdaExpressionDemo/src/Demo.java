
public class Demo {

	public static void main(String[] args) {
		
		Interf i1 = (a,b)->a+b;
		System.out.println(i1.add(10,20));
		System.out.println(i1.add(100,200));
		System.out.println(i1.add(1000,2000));
		i1.m1();
		Interf.m2();
		
	}

}
