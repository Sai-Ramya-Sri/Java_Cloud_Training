@FunctionalInterface
public interface Interf {
	public int add(int a, int b);
	default void m1()
	{
		System.out.println("Hello world!!");
	}
	static void m2()
	{
		System.out.println("Hi world!!");
	}
}