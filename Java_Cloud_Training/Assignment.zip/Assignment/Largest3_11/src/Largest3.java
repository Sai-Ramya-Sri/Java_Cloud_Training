import java.util.Scanner;
public class Largest3{
	
	static int[] find(int[] a, int n)
	{
		int t;
		for(int i=0; i<n-1; i++)
        {
            for(int j=0; j<n-i-1; j++)
            {
                if(a[j]>a[j+1])
                {
                    t=a[j];
                    a[j]=a[j+1];
                    a[j+1]=t;
                }
            }
        }
		return a;
	}
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter n:");
        int n = sc.nextInt();
        int[] a = new int[n];
        System.out.println("Enter "+n+" numbers:");
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        System.out.println("Input is:");
        for(int i=0;i<n;i++)
        {
            System.out.print(a[i]+" ");
        }
        find(a,n);
        System.out.println("\nFirst 3 largest numbers are: ");
        for(int i=n-1;i>=n-3;i--)
        {
            System.out.print(a[i]+" ");
        }
        sc.close();
    }
}