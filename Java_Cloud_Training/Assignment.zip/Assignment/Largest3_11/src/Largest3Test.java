import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Largest3Test {

	@Test
	void test() {
		int[] a = new int[] {0,5,3,2,90};
		a = Largest3.find(a,5);
		assertEquals(90,a[4]);
		assertEquals(5,a[3]);
		assertEquals(3,a[2]);
	}

}
