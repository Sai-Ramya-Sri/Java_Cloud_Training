import java.util.*;
public class ListIteratorDemo {

	public static void main(String[] args) {
		
		LinkedList l = new LinkedList();
		l.add("abc");
		l.add("def");
		l.add("ghi");
		l.add("jkl");
		l.add("mno");
		System.out.println(l);
		
		ListIterator itr = l.listIterator();
		while(itr.hasNext())
		{
			String s= (String)itr.next();
			if(s.equals("def"))
			{
				itr.remove();
			}
		}
		System.out.println(l);

	}

}
