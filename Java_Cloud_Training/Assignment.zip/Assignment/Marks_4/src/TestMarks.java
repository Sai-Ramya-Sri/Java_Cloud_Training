import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestMarks {

	@Test
	void test() {
		int[] a = new int[]{85,43,89,95,97,96,13,54,65,99,94,36,54,87,32,50,68,86,52,100};
		assertEquals(9,marks4.find(a),"Error!");
	}

}
