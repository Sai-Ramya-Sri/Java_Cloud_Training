import java.util.Scanner;

public class marks4{
	
	static int find(int[] a)
	{
		int count=0, j=0;
        while(j<20)
        {
            if(a[j]>=86)
            {
                count++;
            }
            j++;
        }
        return(count); 
	}
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        int[] a = new int[20];
        System.out.println("Enter marks of 20 students:");
        for(int i=0;i<20;i++)
        {
            a[i] = sc.nextInt();
        }
        System.out.println("Marks of 20 students:");
        for(int i=0;i<20;i++)
        {
            System.out.print(a[i]+" ");
        }
        System.out.println("\nNumber of students receiving marks 86 and above: "+find(a));
        sc.close();
    }
}