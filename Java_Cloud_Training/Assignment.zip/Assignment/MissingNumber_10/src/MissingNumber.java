import java.util.Scanner;
public class MissingNumber{
	
	static int find(int[] a,int n)
	{
        int[] r = new int[n+2];
        int k;
		for(int i=0;i<=n+1;i++)
        {
            r[i]=0;
        }
        r[0]=1;
		for(int i=0;i<n;i++)
        {
            k=a[i];
            r[k]=1;
        }
        int i=0;
        while(r[i]==1)
        {
            i++;
        }
        return i;
	}
	
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter n:");
        int n = sc.nextInt();
        int[] a = new int[n];
        System.out.println("Enter "+n+" numbers:");
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        
            System.out.println("Missing number is:"+find(a,n));
            sc.close();
	}
}