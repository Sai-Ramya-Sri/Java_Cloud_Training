import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MissingNumberTest {

	@Test
	void test() {
		int[] a = new int[] {1,0,4,3,2};
		assertEquals(5,MissingNumber.find(a, 5));
	}

}
