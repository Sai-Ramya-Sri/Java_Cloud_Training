import java.util.Scanner;

public class Move0{
    
    public static int[] call(int[] a, int n,int p)
    {
    	
        int k,i=0;
        while(i<n && a[i]!=0)
        {
            i++;
        }
        for(k=i;k<n-1;k++)
        {
            a[k]=a[k+1];
        }
        a[k]=0;
        while(p>0)
        {
        	p--;
            call(a,n,p);
        }
        return a;
    }
    
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        int n;
        System.out.println("Enter length of array:");
        n=sc.nextInt();
        int[] a = new int[n];
        System.out.print("\nEnter array : ");
        for(int i=0;i<n;i++)
        {
            a[i] = sc.nextInt();
        }
        System.out.print("\nInput : ");
        for(int i=0;i<n;i++)
        {
            System.out.print(a[i]+" ");
        }
        int p=0;
        for(int i=0;i<n;i++)
        {
            if(a[i]==0)
            {
                p++;
            }
        }
        call(a,n,p);
        System.out.print("\nOutput : ");
        for(int i=0;i<n;i++)
        {
            System.out.print(a[i]+" ");
        }
        System.out.println();
        sc.close();
    }
}