import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Move0Test {

	@Test
	void test() {
		int[] a = new int[] {1,0,5,0,0};
		int[] b = new int[] {1,5,0,0,0};
		a = Move0.call(a,5,3);
		assertArrayEquals(b,a);
	}

}
