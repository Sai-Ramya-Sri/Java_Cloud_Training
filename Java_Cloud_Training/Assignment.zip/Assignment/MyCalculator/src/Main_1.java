import java.util.*;
import java.lang.Math;

class MyCalculator {
	
	public long power(int n, int p)
	{
		if(n==0 && p==0)
		{
			try {
				throw new Exception("n and p should not be zero");
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
				return -1;
			}
		}
		else if(n<0 || p<0)
		{
			try {
				throw new Exception("n or p should not be negative");
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
				return -1;
			}
		}
		else {
				return (long)Math.pow(n, p);
		}
		
	}
}

class Main_1{
	
	
public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int n,p;
		MyCalculator c = new MyCalculator();
		n = sc.nextInt();
		p = sc.nextInt();
		if(-10<=n && n<=10 && -10<=p && p<=10)
		{
			long r = c.power(n,p);
			if(r!=-1)
			{
				System.out.println(r);
			}
		}
		else {
			System.out.println("Enter values between -10 and 10(both inclusive)");
		}
		sc.close();
		

	}
}


