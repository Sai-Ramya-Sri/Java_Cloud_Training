import java.util.Scanner;

public class Pattern{
	
	static int call(int n)
	{
		int k=1;
		for(int i=1;i<=n;i++)
        {
            k=1;
            while(k<=i)
            {
                System.out.print(k+" ");
                k++;
            }
            System.out.println();
        }
        return k;
	}
    
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        int n;
        System.out.println("Enter n : ");
        n = sc.nextInt();
        call(n);
        sc.close();
    }
}