import java.util.Scanner;

public class Pattern{
	
	static int call(int n)
	{int i,k;
		for(i=n;i>0;i--)
        {
            k=i;
            while(k>0)
            {
                System.out.print("* ");
                k--;
            }
            System.out.println();
        }
        return i;
	}
	
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        int n;
        System.out.println("Enter n : ");
        n = sc.nextInt();
        call(n);
        sc.close();
    }
}