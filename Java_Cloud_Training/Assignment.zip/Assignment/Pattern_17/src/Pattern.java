import java.util.Scanner;

public class Pattern{
	
	static int call(int n)
	{
		int count=n,k,i;
        for(i=0;i<n;i++)
        {
            k=0;
            for(int j=0;j<count-1;j++)
            {
                System.out.print("\t");
            }
            while(k<=i)
            {
                System.out.print("*\t");
                k++;
            }
            System.out.println();
            count--;
        }
        return i;
	}
    
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        int n;
        System.out.println("Enter n : ");
        n = sc.nextInt();
        call(n);
        sc.close();
    }
}