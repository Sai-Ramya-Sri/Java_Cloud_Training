import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PatternTest {

	@Test
	void test() {
		assertEquals(4,Pattern.call(4));
	}

}
