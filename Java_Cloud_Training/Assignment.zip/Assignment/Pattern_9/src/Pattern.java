import java.util.Scanner;
public class Pattern{
	
	static int call(int n)
	{
		int k,i,a=n-1;
        System.out.println();
        for(i=1; i<=n; i++)
        {
            k=1;
            for(int j=0; j<a; j++)
            {
                System.out.print("\t");
            }
            while(k<=i)
            {
                System.out.print(k+"\t");
                k++;
            }
            k-=2;
            while(k>0)
            {
                System.out.print(k+"\t");
                k--;
            }
            a--;
            System.out.print("\n");
        }
        return i;
	}

     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number:");
        int n = sc.nextInt();
        call(n);
        sc.close();
     }
}