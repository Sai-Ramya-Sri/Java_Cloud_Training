class Goods{
	
	public int goodsId;
	public String goodsName;
	public int goodsQuantity;
	public double goodsPrice;
	
	public void addGoods()
	{
		
	}
	public void removeGoods()
	{
		
	}
	public void orderGoods()
	{
		
	}
	public void updateGoods()
	{
		
	}
}

class Supplier{
	
	public int supplierId;
	public String supplierName;
	public String supplierAddress;
	public int quantityOrder;
	public int orderId;
	public double amount;
	
	public void addSupplier()
	{
		
	}
	public void removeSupplier()
	{
		
	}
	public void updateSupplier()
	{
		
	}
}

class Retailer{
	
	public String retailerName;
	public String retailerAddress;
	
	public void viewGoods()
	{
		
	}
	public void viewCustomer()
	{
		
	}
	public void viewSupplier()
	{
		
	}
	
}

class Customer{
	
	public int customerId;
	public String customerName;
	public String customerAddress;
	public String paymentMode;
	
	public void addCustomer()
	{
		
	}
	
	public void removeCustomer()
	{
		
	}
	public void updateCustomer()
	{
		
	}
}

public class Main {

	public static void main(String[] args) {
		

	}

}
