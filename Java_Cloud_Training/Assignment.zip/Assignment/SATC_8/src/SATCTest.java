import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SATCTest {

	@Test
	void test() {
		int n = 2;
		int[] num = new int[] {1,2};
        String[] ln = new String[] {"LN1","LN2"};
        String[] fn = new String[] {"FN1","FN2"};
        String[] mn = new String[] {"MN1","MN2"};
        int[] dep = new int[] {5,6};
        String[] spanish = new String[] {"YES","YES"};
        String[] hd = new String[] {"BA","BA"};
        int[] year = new int[] {10,4};
		
        assertEquals(1,SATC.cal(n, num, ln, fn, mn, dep, spanish, hd, year));
		
	}

}
