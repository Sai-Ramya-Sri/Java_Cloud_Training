import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter radius, color and filled(true/false) of circle");
		double r = sc.nextDouble();
		String c = sc.next();
		boolean f = sc.nextBoolean();
		Circle c1 = new Circle(r,c,f);
		
		System.out.println("Enter width, length, color and filled(true/false) of rectangle");
		double w = sc.nextDouble();
		double l = sc.nextDouble();
		c = sc.next();
		f = sc.nextBoolean();
		Rectangle r1 = new Rectangle(w,l,c,f);
		
		System.out.println("Enter side, color and filled(true/false) of square");
		l = sc.nextDouble();
		c = sc.next();
		f = sc.nextBoolean();
		Square s1 = new Square(l,c,f);
		
		
		System.out.println("\nCircle details : "+c1.toString());
		System.out.println("Rectangle details : "+r1.toString());
		System.out.println("Square details : "+s1.toString());
		
		
		
		
		sc.close();
		

	}

}

abstract class Shape{
	protected String color;
	protected boolean filled;
	
	public Shape()
	{
		
	}
	public Shape(String color, boolean filled)
	{
		this.color = color;
		this.filled = filled;
	}
	public String getColor() {
		return this.color;
	}
	public void setColor(String color)
	{
		this.color = color;
	}
	public boolean isFilled()
	{
		return this.filled;
	}
	public void setFilled(boolean filled)
	{
		this.filled = filled;
	}
	public abstract double getArea();
	public abstract double getPerimeter();
	public abstract String toString();
}

class Circle extends Shape{
	protected double radius;
	
	public Circle() {
	}
	public Circle(double radius)
	{
		this.radius = radius;
	}
	public Circle(double radius, String color, boolean filled)
	{
		super(color,filled);
		this.radius = radius;
	}
	public double getRadius()
	{
		return this.radius;
	}
	public void setRadius(double radius)
	{
		this.radius = radius;
	}
	public double getArea()
	{
		return this.radius*this.radius*3.14;
	}
	public double getPerimeter()
	{
		return this.radius*2*3.14;
	}
	public String toString()
	{
		return "Circle[radius="+this.radius+",color="+super.getColor()+",filled="+super.isFilled()+"]";
	}	
}

class Rectangle extends Shape{
	protected double width;
	protected double length;
	
	 public Rectangle()
	 {
		 
	 }
	 public Rectangle(double width, double length)
	 {
		 this.width = width;
		 this.length = length;
	 }
	 public Rectangle(double width, double length, String color, boolean filled)
	 {
		 super(color, filled);
		 this.length = length;
		 this.width = width;
	 }
	 public double getWidth()
	 {
		 return this.width;
	 }
	 public void setWidth(double width)
	 {
		 this.width = width;
	 }
	 public double getLength()
	 {
		 return this.length;
	 }
	 public void setLength(double length)
	 {
		 this.length = length;
	 }
	 public double getArea()
	 {
		 return this.length*this.width;
	 }
	 public double getPerimeter()
	 {
		 return 2*(this.length+this.width);
	 }
	 public String toString()
	 {
		 return "Rectangle[width="+this.width+",length="+this.length+",color="+super.getColor()+",filled="+super.isFilled()+"]";
	 }
}

class Square extends Rectangle{
	public Square()
	{
		
	}
	public Square(double side)
	{
		super(side,side);
	}
	public Square(double side, String color, boolean filled)
	{
		super(side, side, color, filled);
	}
	public double getSide()
	{
		return super.getLength();
	}
	public void setSide(double side)
	{
		super.setWidth(side);
		super.setLength(side);
	}
	public void setWidth(double side)
	{
		super.setWidth(side);
	}
	public void setLength(double side)
	{
		super.setLength(side);
	}
	public String toString()
	{
		return "Square[side="+this.getSide()+",color="+super.getColor()+",filled="+super.isFilled()+"]";
	}
}