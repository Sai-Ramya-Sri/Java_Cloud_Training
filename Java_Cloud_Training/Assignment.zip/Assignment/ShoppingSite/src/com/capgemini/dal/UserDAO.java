package com.capgemini.dal;
import java.util.ArrayList;
import com.capgemini.pojo.*;
import com.capgemini.util.ConnectionFactory;


public class UserDAO {
	
	ArrayList<UserDetailss> userDetailsList = null;
	public static ArrayList<ProductDetails> productDetailsList = ConnectionFactory.getConnectionVer3();
	
	public UserDAO() {
		userDetailsList = ConnectionFactory.getConnectionVer2();
		userDetailsList.add(new UserDetailss("Ashish", "java", "Admin"));
		userDetailsList.add(new UserDetailss("Tanya", "sql", "User"));
		userDetailsList.add(new UserDetailss("Saifi", "j2ee", "Admin"));
		userDetailsList.add(new UserDetailss("Nikhil", "java", "User"));
		userDetailsList.add(new UserDetailss("Karthik", "sql", "Admin"));
	}
	
	public void getProductDetails(String productName) {
		
		for(ProductDetails p : productDetailsList)
		{
			if(p.getProductName().equals(productName))
			{
				
				//document.getElementById("retrieveDetails").style.visibility="visible";
			}
		}
	}
	
	public String getuserType(String userName, String password)
	{
		for(UserDetailss user : userDetailsList )
		{
			if(user.getUserName().equals(userName) && user.getPassword().equals(password))
			{
				return user.getUserType();
			}
		}
		throw new InvalidUserException("User does not exist");
	}
}
