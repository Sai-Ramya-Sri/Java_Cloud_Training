package com.capgemini.pojo;

public class ProductDetails {
	
	String productName, productID, productDescription;

	public ProductDetails(String productName, String productID, String productDescription) {
		this.productName = productName;
		this.productID = productID;
		this.productDescription = productDescription;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductID() {
		return productID;
	}

	public void setProductID(String productID) {
		this.productID = productID;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	
}
