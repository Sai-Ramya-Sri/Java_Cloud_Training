package com.capgemini.servlet;

import com.capgemini.pojo.ProductDetails;
import com.capgemini.util.ConnectionFactory;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.ArrayList;
import com.capgemini.dal.UserDAO;


@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public AddServlet() {
    	
    	
    }
    
    
    
    public void doCommon(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
    	
    	String productName = request.getParameter("productNameAdd");
    	String productID = request.getParameter("productIDAdd");
    	String productDescription = request.getParameter("productDescriptionAdd");
    	
    	UserDAO.productDetailsList.add(new ProductDetails(productName, productID, productDescription));
    	for(ProductDetails p: UserDAO.productDetailsList)
    	{
    		System.out.println(p.getProductName());
    	}
    	RequestDispatcher requestDispatcher;
    	requestDispatcher = request.getRequestDispatcher("/admin.jsp");
    	requestDispatcher.forward(request, response);
    }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doCommon(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doCommon(request, response);
	}

}
