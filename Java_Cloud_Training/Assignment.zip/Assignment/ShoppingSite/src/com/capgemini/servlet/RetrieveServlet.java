package com.capgemini.servlet;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletRequest;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.dal.UserDAO;
import com.capgemini.pojo.ProductDetails;

/**
 * Servlet implementation class RetrieveServlet
 */
@WebServlet("/RetrieveServlet")
public class RetrieveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public RetrieveServlet() {
        
    }
    
    public void doCommon(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
    	String productName = request.getParameter("productNameRetrieve");
    	System.out.println(productName+"  !  ");
    	
    	for(ProductDetails p : UserDAO.productDetailsList)
    	{
    		System.out.println(p.getProductName()+"  @  ");
    		if(p.getProductName().equals(productName))
    		{
    			
//    			HttpSession session=request.getSession();
//    			session.setAttribute("ProductName",p.getProductName());
//    			session.setAttribute("ProductID",p.getProductID());
//    			session.setAttribute("ProductDetails",p.getProductDescription());
    			//System.out.println("Session "+ session.getAttribute("ProductName"));
    			//RequestDispatcher requestDispatcher;
    	       // request.setAttribute("productNameRetrieveDetails", p.getProductName());
    			//request.setAttribute("productIDRetrieveDetails", p.getProductID());
    			//request.setAttribute("productDescriptionRetrieveDetails", p.getProductDescription());
    			
    			request.getRequestDispatcher("/retrieveDetails.jsp").forward(request, response);
    			return;
    			
    		}
    	}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doCommon(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doCommon(request, response);
	}

}
