package com.capgemini.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;

import com.capgemini.dal.InvalidUserException;
import com.capgemini.dal.UserDAO;


@WebServlet("/ValidationServlet")
public class ValidationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doCommon(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		RequestDispatcher requestDispatcher;
		UserDAO dao = new UserDAO();
		try {
			String userType = dao.getuserType(userName, password);		
			if(userType.equals("Admin")){
				requestDispatcher = request.getRequestDispatcher("/admin.jsp");
			}
			else if(userType.equals("User")){
				requestDispatcher = request.getRequestDispatcher("/user.jsp");
			}
			else {
				throw new InvalidUserException("User does not exist");
			}
		}
		catch(InvalidUserException e)
		{
			requestDispatcher = request.getRequestDispatcher("/invalid.jsp");
		}
		requestDispatcher.forward(request, response);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doCommon(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doCommon(request, response);
	}

}
