package com.capgemini.util;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import com.capgemini.pojo.UserDetailss;
import com.capgemini.pojo.ProductDetails;

public class ConnectionFactory {
	
	private static Connection connection;
	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost", "root", "");
		return connection;
	}
	
	public static ArrayList<UserDetailss> userDetailslist;
	public static ArrayList getConnectionVer2() {
		userDetailslist = new ArrayList<>();
		return userDetailslist;
	}
	
	public static ArrayList<UserDetailss> productDetailsList;
	public static ArrayList getConnectionVer3() {
		productDetailsList = new ArrayList<>();
		return productDetailsList;
	}
	
	
	public static void main(String[] args)
	{
		try {
			System.out.println(ConnectionFactory.getConnection());
		}
		catch (ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}
	}
}