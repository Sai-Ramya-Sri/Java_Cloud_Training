import java.util.Scanner;
public class smallest{
	
	static int min(int a, int b, int c)
	{
		return( a<b? (a<c? a:c) : (b<c? b:c));
	}
	
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter 3 numbers:");
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();
        System.out.println("Smallest number is "+min(a,b,c));
        sc.close();
     }
}