import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class testSmallest {

	@Test
	void test() {
		assertEquals(3,smallest.min(5,9,3),"Error!");
	}

}
