import java.util.Scanner;
class Sort{
	static int[] sort(int[] a,int n)
	{
		for(int i=0; i<n-1; i++)
        {
            for(int j=0; j<n-i-1; j++)
            {
                if(a[j]>a[j+1])
                {
                    int t=a[j];
                    a[j]=a[j+1];
                    a[j+1]=t;
                }
            }
        }
		return a;
	}
	
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        int n;
        System.out.println("Enter the number of elements in the list:");
        n = sc.nextInt();
        System.out.println("Enter "+n+" numbers:");
        int[] a = new int[n];
        for(int i=0; i<n; i++)
        {
            a[i] = sc.nextInt();
        }
        System.out.println("Unsorted array:");
        for(int i=0; i<n; i++)
        {
            System.out.println(a[i]);
        }
        a = sort(a,n);
        System.out.println("Sorted array:");
        for(int i=0; i<n; i++)
        {
            System.out.println(a[i]);
        }
        sc.close();
     }
}