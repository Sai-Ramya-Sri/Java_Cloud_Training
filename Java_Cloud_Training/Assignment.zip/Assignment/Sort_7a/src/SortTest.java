import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SortTest {

	@Test
	void test() {
		int[] a = new int[] {9,2,4,0,6};
		int[] b = new int[] {0,2,4,6,9};
		assertArrayEquals(b, Sort.sort(a,5) );
	}

}
