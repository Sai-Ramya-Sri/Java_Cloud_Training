import java.util.*;
import java.util.stream.*;
import java.time.*;

public class EmployeeService {
	
	public void getSum(List<Employee> l)
	{
		Stream<Employee> s = l.stream();
		double sum = 0;
		sum+=s.mapToDouble(o->o.getSalary()).sum();
		System.out.println(sum);
	}
	
	public void depCount(List<Employee> l)
	{
		Stream<Employee> stream = l.stream();
		Object[] s = stream.filter(ob->ob.getDepartment()!=null).toArray();
		HashMap<String, Integer> m = new HashMap<>();
		for(Object ob : s)
		{
			Employee e = (Employee)ob;
			String str = e.getDepartment().getDepartmentName();
			Integer deptCount = m.get(str);
			m.put(str,  (deptCount==null)?1:deptCount+1);
		}
		System.out.println(m);
	}
	
	public void snr(List<Employee> l)
	{

		List<Employee> emp = l.stream().filter(obj->obj.getDesignation().equals("President")).collect(Collectors.toList());
		//System.out.println(emp);
		for(Employee e : emp)
		{
			System.out.println(e.getFirstName()+" "+e.getLastName());
		}
	}
	
	public void DOS(List<Employee> l)
	{
		List<Employee> emp = l.stream().filter(obj->obj.getFirstName()!=null).collect(Collectors.toList());
		HashMap<String, String> hm = new HashMap<>();
		for(Employee e : emp)
		{
			String str = e.getFirstName()+" "+e.getLastName();
			Period service = Period.between(e.getHireDate(), LocalDate.now());
			Integer m = service.getMonths(), d = service.getDays();
			String s = m+" months and "+d+" days";
			hm.put(str, s);
		}
		System.out.println(hm);
	}
	
	public void EWOD(List<Employee> l)
	{
		List<Employee> emp = l.stream().filter(ob->ob.getDepartment()==null).collect(Collectors.toList());
		for(Employee e : emp)
		{
			System.out.println(e.getFirstName()+" "+e.getLastName());
		}
	}
	
	public void DWOE(List<Department> d, List<Employee> e)
	{
		List<Employee> emp = e.stream().filter(ob->ob.getDepartment()!=null).collect(Collectors.toList());
		List<Department> dep = new ArrayList<>();
		for(Employee em : emp)
		{
			dep.add(em.getDepartment());
		}
		List<Department> dept = d;
		dept.removeAll(dep);
		for(Department de : dept)
		{
			System.out.println(de.getDepartmentName());
		}
	}
	
	public void DWHE(List<Employee> l)
	{
		Stream<Employee> stream = l.stream();
		Object[] s = stream.filter(ob->ob.getDepartment()!=null).toArray();
		HashMap<String, Integer> m = new HashMap<>();
		for(Object ob : s)
		{
			Employee e = (Employee)ob;
			String str = e.getDepartment().getDepartmentName();
			Integer deptCount = m.get(str);
			m.put(str,  (deptCount==null)?1:deptCount+1);
		}
		
		HashMap.Entry<String, Integer> maxEntry = null;
		for (HashMap.Entry<String, Integer> entry : m.entrySet())
		{
		    if (maxEntry == null || entry.getValue().compareTo(maxEntry.getValue()) > 0)
		    {
		        maxEntry = entry;
		    }
		}
		System.out.println(maxEntry.getKey());
		
		
	}
	
	
	public String getNameFromID(List<Employee> l, Integer id)
	{
		for(Employee e : l)
		{
			if(e.getEmployeeId()==id)
				return e.getFirstName()+" "+e.getLastName();
		}
		return null;
	}
	
	public void ManagerSubordinates(List<Employee> l)
	{
		//List<Employee> emp = l.stream().filter(ob->ob.getManagerId()!=null).collect(Collectors.toList());
		//System.out.println(emp);
		
		HashMap<Integer, String> hm = new HashMap<>();
		
		
		
		
		
//		HashMap<String,List<Employee>> personByCity =  l.stream().collect(Collectors.groupingBy(Employee::getManagerID));
	}
	
	
	
	
	
	
	
	
	
	
	public static void main(String[] args)
	{
		List<Employee> e = EmployeeRepository.getEmployees();
		List<Department> d = EmployeeRepository.getDepartments();
		
		EmployeeService es = new EmployeeService();
		System.out.print("Sum of salary of all employees : ");
		es.getSum(e);
		System.out.println("\nList of department names and count of employees in each department : ");
		es.depCount(e);
		System.out.println("\nSenior most employee of the organization : ");
		es.snr(e);
		System.out.println("\nList of employee name and duration of their service in months and days : ");
		es.DOS(e);
		System.out.println("\nEmployees without department : ");
		es.EWOD(e);
		System.out.println("\nDepartments without employees : ");
		es.DWOE(d, e);
		System.out.println("\nDepartment with highest count of employees : ");
		es.DWHE(e);
		System.out.println("\nEmployee name\t\t\tHire date\t\tDay of week");
		for(Employee em:e)
		{
			System.out.println(em.getFirstName()+" "+em.getLastName()+"\t\t\t"+em.getHireDate()+"\t\t"+em.getHireDate().getDayOfWeek());
		}
		System.out.println("\nEmployees who joined on Friday : ");
		System.out.println("Employee name\tHire date\tDay of week");
		for(Employee em:e)
		{
			if(em.getHireDate().getDayOfWeek().toString().equals("FRIDAY"))
				System.out.println(em.getFirstName()+" "+em.getLastName()+",\t"+em.getHireDate()+",\t"+em.getHireDate().getDayOfWeek());
		}
		
		System.out.println("\nEmployee�s names and names of manager to whom he/she reports :\nEmployee Name\t\tManager Name");
		for(Employee em : e)
		{
			Integer i =  em.getManagerId();
			System.out.println(em.getFirstName()+" "+em.getLastName()+"\t\t"+es.getNameFromID(e,i));
		}
		System.out.println("\nEmployee name\t\tSalary\t\tIncreased Salary");
		double sal;
		for(Employee em : e)
		{
			sal = em.getSalary()+em.getSalary()*15/100;
			System.out.println(em.getFirstName()+" "+em.getLastName()+"\t\t"+em.getSalary()+"\t\t"+sal);
		}
		System.out.println("\nEmployees without manager : ");
		for(Employee em : e)
		{
			if(em.getManagerId()==null)
			{
				System.out.println(em.getFirstName()+" "+em.getLastName());
			}
		}
		System.out.println("\nManager\tSubordinates");
		es.ManagerSubordinates(e);
		
		
		
		
	}
}