public class Main_1 {

	public static void main(String[] args) {
		
		String str = "Welcome to Java World";
		
		System.out.println("Character at 5th position is : "+str.charAt(5));
		System.out.println("Comparing the String 'Welcome to Java World' with 'Welcome' lexicographically ignoring case differences... Result : "+str.compareToIgnoreCase("Welcome"));
		str+="-Let us learn";
		System.out.println(str);
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)=='a')
			{
				System.out.println("Position of the first occurrence of character �a� : "+i);
				break;
			}
		}
		System.out.println("String after replacing all the occurrences of �a� character with the new �e� : "+str.replaceAll("a", "e"));
		System.out.println("String between 4th position and 10th position is : "+str.substring(4, 11));
		System.out.println("Lowercase of the string : "+str.toLowerCase());
	}
}