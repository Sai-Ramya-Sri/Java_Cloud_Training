public class Main_2 {

	public static void main(String[] args) {
		
		StringBuffer sb = new StringBuffer("This is StringBuffer");
		System.out.println("StringBuffer : "+sb);
		System.out.println("After adding the string '-This is a sample program' : "+sb.append("-This is a sample program"));
		System.out.println("After inserting the string 'Object' into the existing string at 21st position : "+sb.insert(20, "Object"));
		System.out.println("Reverse : "+sb.reverse());
		System.out.println("Replacing the word 'Buffer' with 'Builder' : "+sb.reverse().replace(15,20, "Builder"));
	}
}
