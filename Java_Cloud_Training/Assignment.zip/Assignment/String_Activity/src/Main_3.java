public class Main_3 {

	public static void main(String[] args) {
		
		String s = new String("C:\\IBM\\DB2\\PROGRAM\\DB2COPY1.EXE");
		//System.out.println(s);
		String[] str = s.split("\\\\");
		System.out.println("Drive: "+str[0].toLowerCase()+"\\");
		System.out.println("Folders: "+str[1]+" || "+str[2]+" || "+str[3]);
		System.out.println("File: "+str[4]);
	}
}
