import java.util.Scanner;
class SumOfDigits{
	
	static int sum(int n)
	{
		int sum=0, d;
        while(n>0)
        {
            d = n%10;
            n/=10;
            sum+=d;
        }
        return sum;
	}
	
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number:");
        int n = sc.nextInt();
        
        System.out.println("Sum of digits of "+n+" is: "+sum(n));
        sc.close();
     }
}