import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SumOfDigitsTest {

	@Test
	void test() {
		assertEquals(9,SumOfDigits.sum(540));
	}

}
