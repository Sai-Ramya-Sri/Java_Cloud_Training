import java.util.Scanner;
public class SwapUsingTemp{
	
	public static int[] swap(int a, int b)
	{
		int t=a;
        a=b;
        b=t;
        int[] n = new int[] {a,b};
        return n;
	}
	
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        int[] n = new int[2];
        System.out.println("Enter 2 numbers:");
        n[0] = sc.nextInt();
        n[1] = sc.nextInt();
        System.out.println("Numbers before swapping: "+n[0]+" "+n[1]);
        n=swap(n[0],n[1]);
        System.out.println("Numbers after swapping: "+n[0]+" "+n[1]);
        sc.close();
     }
}