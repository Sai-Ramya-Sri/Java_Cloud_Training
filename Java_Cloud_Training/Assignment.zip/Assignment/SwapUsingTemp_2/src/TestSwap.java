import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestSwap {

	@Test
	void test() {
		int[] n = SwapUsingTemp.swap(3,8);
		int[] n1 = new int[] {8,3};
		assertArrayEquals(n1,n);
	}

}
