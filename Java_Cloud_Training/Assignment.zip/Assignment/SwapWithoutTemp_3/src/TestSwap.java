import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestSwap {

	@Test
	void test() {
		int[] n = SwapWithoutTemp.swap(9,50);
		int[] n1 = new int[] {50,9};
		assertArrayEquals(n1,n);
	}
}
