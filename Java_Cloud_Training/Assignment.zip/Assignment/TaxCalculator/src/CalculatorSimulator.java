class CountryNotValidException extends Exception{
	public CountryNotValidException(String s)
	{
		super(s);
	}
}

class EmployeeNameInvalidException extends Exception{
	public EmployeeNameInvalidException(String s)
	{
		super(s);
	}
}

class TaxNotEligibleException extends Exception{
	public TaxNotEligibleException(String s)
	{
		super(s);
	}
}


class TaxCalculator {
	
	public double calculateTax(String empName, boolean isIndian, double empSal)
	{
		int flag=0;
		double taxAmount=0;
		try {
			if(isIndian!=true)
			{
				flag=1;
				throw new CountryNotValidException("The employee should be an Indian citizen for calculating tax");
			}
		}
		catch (CountryNotValidException c)
			{
				System.out.println(c.getMessage());
				c.printStackTrace();
			}
		try {
			if(empName.length()==0 && flag==0 )
			{
				flag=1;
				throw new EmployeeNameInvalidException("The employee name cannot be empty");
			}
		}
		catch(EmployeeNameInvalidException e){
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		try {
		if(empSal>100000 && flag==0)
		{
			taxAmount = empSal*8/100;
		}
		else if(empSal>50000 && flag==0)
		{
			taxAmount = empSal*6/100;
		}
		else if(empSal>30000 && flag==0)
		{
			taxAmount = empSal*5/100;
		}
		else if(empSal>10000 && flag==0)
		{
			taxAmount = empSal*4/100;
		}
		else if(flag==0) {
			throw new TaxNotEligibleException("The employee does not need to pay tax");
		}
	}
		catch(TaxNotEligibleException t)
		{
			System.out.println(t.getMessage());
			t.printStackTrace();
		}
		return taxAmount;
		}
		
}		
	
class CalculatorSimulator{
	
	public static void main(String[] args) {
		
		TaxCalculator tc = new TaxCalculator();
		double r = tc.calculateTax("Ron",false,34000);
		if(r!=0)
		{
			System.out.println("Tax amount is "+r);
		}
		r = tc.calculateTax("Tim",true,1000);
		if(r!=0)
		{
			System.out.println("Tax amount is "+r);
		}
		r = tc.calculateTax("Jack",true,55000);
		if(r!=0)
		{
			System.out.println("Tax amount is "+r);
		}
		r = tc.calculateTax("",true,30000);
		if(r!=0)
		{
			System.out.println("Tax amount is "+r);
		}	
	}
}