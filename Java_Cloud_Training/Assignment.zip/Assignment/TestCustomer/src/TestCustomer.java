import java.util.*;

class InvalidInputException extends Exception{
	public InvalidInputException(String s)
	{
		super(s);
	}
}

class Customer{
	private String custNo;
	private String custName;
	private String category;
	
	public Customer(String no, String name, String c)
	{
		try {
			if(!(no.charAt(0)=='C' || no.charAt(0)=='c') )
			{
				throw new InvalidInputException("Invalid Customer Number");
			}
			if(name.length()<4)
			{
				throw new InvalidInputException("Invalid Customer Name");
			}
			if(!(c.equalsIgnoreCase("Platinum") || c.equalsIgnoreCase("Gold") || c.equalsIgnoreCase("Silver") ))
			{
				throw new InvalidInputException("Invalid Category");
			}
		}
		catch(InvalidInputException ie)
		{
			System.out.println(ie.getMessage());
			System.exit(0);
		}
		this.custNo = no;
		this.custName = name;
		this.category = c;
	}
	
	public String getCustNo()
	{
		return this.custNo;
	}
	public String getCustName()
	{
		return this.custName;
	}
	public String getCategory()
	{
		return this.category;
	}
	
}

public class TestCustomer {
	
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		
		System.out.println("Enter Customer's Number(Must start with 'C' or 'c'), Name(At least 4 characters) and Category(Platinum, Gold or Silver) : ");
		
		String no = sc.next();
		String name = sc.next();
		String c = sc.next();
		
		Customer c1 = new Customer(no,name,c);
		
		System.out.println("Valid Input\\nCustomer's details :\nCustomer Number : "+c1.getCustNo()+"\nCustomer Name : "+c1.getCustName()+"\nCategory : "+c1.getCategory());
		
		sc.close();
	}
}
