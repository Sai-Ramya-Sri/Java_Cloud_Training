import java.util.*;
import java.lang.*;
public class palindrome{

     public static void main(String []args){
        
        Scanner sc = new Scanner(System.in);
        
        int n = sc.nextInt();
        int d,s=0,num=n;
        if(n<0)
        {
            System.out.println("false");
            System.exit(0);
        }
        while(n>0)
        {
            d=n%10;
            s = s*10+d;
            n/=10;
        }
        
        if(s==num)
        {
            System.out.println("true");
        }
        else
        {
            System.out.println("false");
        }
     }
}