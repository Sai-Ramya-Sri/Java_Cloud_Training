import java.util.*;
public class discount{
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        int newItem = sc.nextInt();
        int discount = newItem*35/100;
        int newItemPrice = newItem-discount;
        System.out.println("New Item Price is: "+newItemPrice);
    }
}