import java.util.*;
public class incometax{

     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int tax=0;
        if(n <= 180000)
        {
            tax=0;
        }
        else if(n<=300000)
        {
            tax = n/10;
        }
        else if(n<=500000)
        {
            tax = n/5;
        }
        else if(n<=1000000)
        {
            tax = n*3/10;
        }
        System.out.println("Tax is: "+tax);
        
    }
}