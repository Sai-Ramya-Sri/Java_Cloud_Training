import java.util.*;
import java.lang.*;
public class stringrev{
    
    public static void reverse(String str)
   {

	    String[] w = str.split(" ");
	    String res = "";
	    for (int i=0;i<w.length;i++)
        {
           String word = w[i];
           String resw = "";
           for (int j=word.length()-1;j>=0;j--) 
	        {
        		resw+=word.charAt(j);
	        }
	        res+=(resw+" ");
	    }
	    System.out.println(res);
   }
    
     public static void main(String []args){
        
        Scanner sc = new Scanner(System.in);
        
        String str = sc.nextLine();
        reverse(str);
    }
}