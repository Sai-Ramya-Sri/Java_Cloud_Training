import java.util.*;

public class palindromewords{
    
    public static int check(char[] word){
        int i1 = 0;
        int i2 = word.length-1;
        while (i2 > i1) {
            if (word[i1] != word[i2]) {
                return 0;
            }
            ++i1;
            --i2;
        }   
        return 1;
    }

     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        
        String[] str = new String[10];
        for(int i=0;i<10;i++)
        {
            str[i] = sc.next();
        }
        for(int i=0;i<10;i++)
        {
            char[] p = str[i].toCharArray();
            if(check(p)==1)
            {
                System.out.println(str[i]);
                System.out.println(str[i].length());
                Arrays.sort(p);
                for(int k=p.length-1;k>=0;k--)
                {
                    System.out.print(p[k]);
                }
                System.out.println();
            }
            
            

        }
        
    }
}