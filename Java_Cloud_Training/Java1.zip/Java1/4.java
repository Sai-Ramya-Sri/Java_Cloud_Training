import java.util.*;
public class duplicate{
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int n = sc.nextInt();
        int[] a = new int[n];
        int k,i,j,count=0;
        System.out.println("Enter array and a number:");
        for(i=0;i<n;i++)
        {
            a[i] = sc.nextInt();
        }
        k = sc.nextInt();
        
        i=0;
		System.out.println("Input elements satisfying the given condition are:");
        while(i<n)
        {
            for(j=i+1;j<n;j++)
            {
                if(a[i]==a[j])
                {
                    if((j-i)<=k)
                    {
//						count++;
                        System.out.println(a[i]);
                    }
                }
            }
        i++;
        }
//        System.out.println(count);
    }
}