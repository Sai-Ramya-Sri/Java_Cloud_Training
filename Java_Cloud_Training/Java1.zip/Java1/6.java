import java.util.*;
public class name{
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of names:");
        int n = sc.nextInt();
        int count=0;
		System.out.println("Enter "+n+" names:");
        String[] names = new String[n];
        for(int i=0;i<n;i++)
        {
            names[i] = sc.next();
        }
		System.out.println("Enter a name to search:");
        String word = sc.next();
        
/*        String s = sc.nextLine();
        String word = sc.next();
        String[] names = s.split(",");
        int nl = names.length,count=0;
        names[nl-1] = names[nl-1].substring(0,names[nl-1].length()-1);
        for(int i=0;i<nl;i++)
        {
            names[i] = names[i].substring(2);
            names[i] = names[i].substring(0,names[i].length()-1);
        }
        */
        for(int i=0;i<n;i++)
        {
            if(word.equals(names[i]))
            {
                count++;
            }
        }
        System.out.println("Number of times the name "+word+" appeared in the list is: "+count);
    }
}