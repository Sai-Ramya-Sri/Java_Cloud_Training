import java.util.*;
public class duplicate{

     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        
        String str = sc.next();
        
        char[] ch = str.toCharArray();
        int l = ch.length;
        char[] r = new char[l];
        int k,count=0;
        for(int i=0;i<l;i++)
        {
            k=0;
            while(r[k]!='\0')
            {
                if(r[k] == ch[i])
                {
                    count++;
                    break;
                }
                k++;
            }
            r[k++]=ch[i];
        }
        for(int i=0;i<(l-count);i++)
        System.out.print(r[i]);
        
     }
}