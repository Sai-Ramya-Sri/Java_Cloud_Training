import java.util.*;
public class blanks{
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        String in = sc.nextLine();
        String word = sc.next();
        int pos = sc.nextInt();
        int count=0,k=0;
		String s = in.replaceAll("\\s+"," ");
        String[] str = s.split(" ");
        String s1="";
        int i;
        int[] q = new int[str.length];
        for(i=0;i<str.length;i++)
        {
            
            q[k++] = str[i].length();
            s1 = s1.concat(" ");
            s1 = s1.concat(str[i]);
        }
        s1 = s1.substring(1);
        int len = word.length();
        int a=0;
        for(i=0;i<pos-1;i++)
        {
            a+=q[i];
        }
        a+=i-1;
        System.out.println(s1.substring(0,a).concat(s1.substring(a+1+len)));
    }
}