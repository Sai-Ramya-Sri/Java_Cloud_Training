import java.util.*;
import java.lang.*;
public class MultiDimensionalArray{
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the number of rows:");
        int m = sc.nextInt();
        System.out.println("Enter the lengths of "+m+" rows:");
        int[] n = new int[m];
        for(int i=0; i<m;i++)
        {
            n[i] = sc.nextInt();
        }
        int max = n[0];
        for(int i=1; i<m; i++)
        {
            if(n[i]>max)
            {
                max = n[i];
            }
        }
        int[][] a = new int[m][max];
        int p = 0;
        System.out.println("Enter the elements of the multi-dimensional array:");
        while(p<m)
        {
            for(int i=0; i<n[p];i++)
            {
                a[p][i] = sc.nextInt();
            }
            p++;
        }
        System.out.println("Enter a number:");
        int num = sc.nextInt();
        
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<n[i];j++)
            {
                if(num==a[i][j])
                {
                    System.out.println("The given number is present in the input multi-dimensional array");
                    System.exit(0);
                }
            }
        }
        System.out.println("The given number is present not in the input multi-dimensional array");
    }
}