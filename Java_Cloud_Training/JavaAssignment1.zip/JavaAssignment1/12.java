import java.util.Scanner;

public class Common{
    public static int[] find(int[] a, int[] b, int l, int m, int max)
    {
        int[] r = new int[max+1];
        int i=0,j=0,k=1;
        while(i<l && j<m)
        {
            if(a[i]==b[j])
            {
                r[k++]=a[i];
                i++;
                j++;
            }
            else if(a[i]<b[j])
            {
                i++;
            }
            else
            {
                j++;
            }
        }
        r[0]=k-1;
        return r;
    }
    
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        int l,m,n;
        System.out.println("Enter lengths of 3 arrays:");
        l=sc.nextInt();
        m=sc.nextInt();
        n=sc.nextInt();
        int[] a = new int[l];
        int[] b = new int[m];
        int[] c = new int[n];
        int max = (l>m? (l>n?l:n) : (m>n?m:n));
        int[] r = new int[max];
        System.out.println("Enter first array:");
        for(int i=0;i<l;i++)
        {
            a[i]=sc.nextInt();
        }
        System.out.println("Enter second array:");
        for(int i=0;i<m;i++)
        {
            b[i]=sc.nextInt();
        }
        System.out.println("Enter third array:");
        for(int i=0;i<n;i++)
        {
            c[i]=sc.nextInt();
        }
        System.out.print("\nArray 1: ");
        for(int i=0;i<l;i++)
        {
            System.out.print(a[i]+" ");
        }
        System.out.print("\nArray 2: ");
        for(int i=0;i<m;i++)
        {
            System.out.print(b[i]+" ");
        }
        System.out.print("\nArray 3: ");
        for(int i=0;i<n;i++)
        {
            System.out.print(c[i]+" ");
        }
        r=find(a,b,l,m,max);
        max=r[0];
        for(int i=0;i<max;i++)
        {
        	r[i]=r[i+1];
        }
        r=find(r,c,max,n,max);
        System.out.println("\nCommon numbers are:");
        for(int i=1;i<=r[0];i++)
        {
            System.out.print(r[i]+" ");
        }
        sc.close();
    }
}