import java.util.Scanner;

public class pattern14{
    
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        int n,k;
        n = sc.nextInt();
        for(int i=1;i<=n;i++)
        {
            k=1;
            while(k<=i)
            {
                System.out.print(k+" ");
                k++;
            }
            System.out.println();
        }
    }
}