import java.util.Scanner;

public class pattern15{
    
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        int n,k;
        n = sc.nextInt();
        for(int i=n;i>0;i--)
        {
            k=i;
            while(k>0)
            {
                System.out.print("* ");
                k--;
            }
            System.out.println();
        }
    }
}