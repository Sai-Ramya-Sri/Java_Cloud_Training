import java.util.Scanner;

public class pattern16{
    
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        int r=64,n,k;
        n = sc.nextInt();
        for(int i=1;i<=n;i++)
        {
            k=i;
            while(k>0)
            {
                char ch = (char)(r+i);
                System.out.print(ch+" ");
                k--;
            }
            System.out.println();
        }
        
    }
}