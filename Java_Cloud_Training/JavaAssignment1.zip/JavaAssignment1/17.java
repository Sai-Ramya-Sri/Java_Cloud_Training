import java.util.Scanner;

public class pattern17{
    
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        int r=64,n,k;
        n = sc.nextInt();
        int count=n;
        for(int i=0;i<n;i++)
        {
            k=0;
            for(int j=0;j<count-1;j++)
            {
                System.out.print("\t");
            }
            while(k<=i)
            {
                System.out.print("*\t");
                k++;
            }
            System.out.println();
            count--;
        }
    }
}