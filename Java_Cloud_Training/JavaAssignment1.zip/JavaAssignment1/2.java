import java.util.Scanner;
public class swapusingtemp{

     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter 2 numbers:");
        int a = sc.nextInt();
        int b = sc.nextInt();
        System.out.println("Numbers before swapping: "+a+" "+b);
        int t=a;
        a=b;
        b=t;
        System.out.println("Numbers after swapping: "+a+" "+b);
     }
}