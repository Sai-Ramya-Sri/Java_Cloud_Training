import java.util.Scanner;

public class marks4{
    
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        int n=20;
        int[] a = new int[20];
        System.out.println("Enter marks of 20 students:");
        for(int i=0;i<20;i++)
        {
            a[i] = sc.nextInt();
        }
        System.out.println("Marks of 20 students:");
        for(int i=0;i<20;i++)
        {
            System.out.print(a[i]+" ");
        }
        int count=0, i=0;
        while(i<20)
        {
            if(a[i]>=86)
            {
                count++;
            }
            i++;
        }
        System.out.println("\nNumber of students receiving marks 86 and above: "+count);
        
    }
}