import java.util.Scanner;
public class add{

     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter 2 numbers:");
        int a = sc.nextInt();
        int b = sc.nextInt();
        System.out.println("Sum of "+a+" and "+b+" is "+(a+b));
     }
}