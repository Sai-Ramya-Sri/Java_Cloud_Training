import java.util.Scanner;
public class sumofdigits{

     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number:");
        int n = sc.nextInt();
        int num=n, sum=0, d;
        while(n>0)
        {
            d = n%10;
            n/=10;
            sum+=d;
        }
        System.out.println("Sum of digits of "+num+" is: "+sum);
     }
}