import java.util.Scanner;

public class SATC8{
    
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        int n;
        
        System.out.println("Enter the number of candidates:");
        n = sc.nextInt();
        int[] num = new int[n];
        String[] ln = new String[n];
        String[] fn = new String[n];
        String[] mn = new String[n];
        int[] dep = new int[n];
        String[] spanish = new String[n];
        String[] hd = new String[n];
        int[] year = new int[n];
        System.out.println("Enter Employee number, Last name, First Name, Middle initial, Department, Spanish(YES/NO), Highest Degree, experience of "+n+" candidates");
        for(int i=0;i<n;i++)
        {
            num[i] = sc.nextInt();
            ln[i] = sc.next();
            fn[i] = sc.next();
            mn[i] = sc.next();
            dep[i] = sc.nextInt();
            spanish[i] = sc.next();
            hd[i] = sc.next();
            year[i] = sc.nextInt();
        }
        String str = "YES";
        System.out.println("South American Trainer Candidates:");
        System.out.println("Employee ID\tLast Name\tFirst Name\tMiddleInitial\tDepartment");
        
        for(int i=0;i<n;i++)
        {
            if(spanish[i].equals(str))
            {
                if((hd[i].compareTo("AS"))>0)
                {
                    if(year[i]>=5)
                    {
                        System.out.println(num[i]+"\t\t"+ln[i]+"\t\t"+fn[i]+"\t\t"+mn[i]+"\t\t"+dep[i]);
                    }
                }
            }
        }
        
        
    }
}