import java.util.Scanner;
public class pattern9{

     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number:");
        int n = sc.nextInt();
        int k,a=n-1;
        System.out.println();
        for(int i=1; i<=n; i++)
        {
            k=1;
            for(int j=0; j<a; j++)
            {
                System.out.print("\t");
            }
            while(k<=i)
            {
                System.out.print(k+"\t");
                k++;
            }
            k-=2;
            while(k>0)
            {
                System.out.print(k+"\t");
                k--;
            }
            a--;
            System.out.print("\n");
        }
     }
}