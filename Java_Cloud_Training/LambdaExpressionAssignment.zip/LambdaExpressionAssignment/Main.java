@FunctionalInterface
interface interf1{
	public boolean Odd(int n);
}

@FunctionalInterface
interface interf2{
	public boolean Prime(int n);
}

@FunctionalInterface
interface interf3{
	public boolean Palindrome(int n);
}

public class Main {

	public static void main(String[] args) {
		
		interf1 i1 = (n)-> n%2==0?false:true;
		System.out.println("Odd(15) : "+i1.Odd(15));
		System.out.println("Odd(10) : "+i1.Odd(10));
		
		interf2 i2  = (n) -> { for(int i=2;i<=java.lang.Math.sqrt(n);i++)
									if(n%i==0) return(false);
								return(true);
								};
		System.out.println("Prime(5) : "+i2.Prime(5));
		System.out.println("Prime(6) : "+i2.Prime(6));
		
		interf3 i3 = (n) -> { int d,s=0,num=n;	while(n>0)	{	d=n%10;	n/=10;	s=s*10+d;	}	if(num==s) return(true); return(false);	};
		System.out.println("Palindrome(12321) : "+i3.Palindrome(12321));
		System.out.println("Palindrome(123) : "+i3.Palindrome(123));
	}

}
