import java.util.*;

public class Account{
    private String id;
    private String name;
    private int balance = 0;

    public Account(String id, String name)
    {
        this.id = id;
        this.name = name;
    }
    public Account(String id, String name, int balance)
    {
        this.id = id;
        this.name = name;
        this.balance = balance;
    }
    public String getID()
    {
        return this.id;
    }
    public String getName()
    {
        return this.name;
    }
    public int getBalance()
    {
        return this.balance;
    }
    public int credit(int amount)
    {
        this.balance+=amount;
        return this.balance;
    }
    public int debit(int amount)
    {
        if(amount<=this.balance)
        {
            this.balance-=amount;
        }
        else
        {
            System.out.println("Amount exceeded balance");
        }
        return this.balance;
    }
    public int transferTo(Account a, int amount)
    {
        if(amount<=this.balance)
        {
            this.debit(amount);
			a.credit(amount);
        }
        else
        {
            System.out.println("Amount exceeded balance");
        }
        return this.balance;
    }
    public String toString()
    {
        return "Account[id="+this.id+",name="+this.name+",balance="+this.balance+"]";
    }
    
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Account 1:");
        System.out.println("Enter ID : ");
        String id = sc.next();
        System.out.println("Enter Name : ");
        String n = sc.next();
        Account a1 = new Account(id, n);
        
        System.out.println("Account 2:");
        System.out.println("Enter ID : ");
        id = sc.next();
        System.out.println("Enter Name : ");
        n = sc.next();
        System.out.println("Enter Balance : ");
        int b = sc.nextInt();
        Account a2 = new Account(id, n, b);
        
        System.out.println("\nAccount 1:");
        System.out.println("ID : "+a1.getID()+"\nName : "+a1.getName()+"\nBalance : "+a1.getBalance());
        System.out.println("\nAccount 2:");
        System.out.println("ID : "+a2.getID()+"\nName : "+a2.getName()+"\nBalance : "+a2.getBalance());
        
        System.out.println("\nAccount 1 : ");
        System.out.println("Enter amount to be credited: ");
        int a = sc.nextInt();
        a1.credit(a);
        System.out.println("Balance : "+a1.getBalance());
        System.out.println("Enter amount to be debited: ");
        a = sc.nextInt();
        a1.debit(a);
        System.out.println("Balance : "+a1.getBalance());
        
        System.out.println("Enter the amount to transfer from Account 1 to Account 2: ");
        a = sc.nextInt();
        a1.transferTo(a2, a);
        System.out.println("\nAccount 1 : "+a1.toString()+"\nAccount 2 : "+a2.toString());
     }
}