import java.util.*;
public class GradesAverage{
    
    private int numStudents;

    public void input()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of students: ");
        numStudents = sc.nextInt();
        int[] grades = new int[numStudents];
        int x;
        double sum=0;
        for(int i=0;i<numStudents;i++)
        {
            System.out.println("Enter the grade for student "+(i+1)+": ");
            x = sc.nextInt();
            if(x>=0 && x<=100)
            {
                grades[i] = x;
            }
            else
            {
                System.out.println("Invalid grade, try again...");
                i--;
            }
        }
        for(int i=0;i<numStudents;i++)
        {
            sum+=grades[i];
        }
        sum/=numStudents;
        System.out.println("The average is: "+sum);
    }
     public static void main(String []args){
        
        GradesAverage g1 = new GradesAverage();
        g1.input();
     }
}