import java.util.*;

public class InvoiceItem{
    private String id;
    private String desc;
    private int qty;
    private double unitPrice;
    
    public InvoiceItem(String id, String desc, int qty, double unitPrice)
    {
        this.id = id;
        this.desc = desc;
        this.qty = qty;
        this.unitPrice = unitPrice;
    }
    public String getID()
    {
        return this.id;
    }
    public String getDesc()
    {
        return this.desc;
    }
    public int getQty()
    {
        return this.qty;
    }
    public void setQty(int qty)
    {
        this.qty = qty;
    }
    public double getUnitPrice()
    {
        return this.unitPrice;
    }
    public void setUnitPrice(double unitPrice)
    {
        this.unitPrice = unitPrice;
    }
    public double getTotal()
    {
        return this.unitPrice*this.qty;
    }
    public String toString()
    {
        return "InvoiceItem[id="+this.id+",desc="+this.desc+",qty="+this.qty+",unitPrice="+this.unitPrice+"]";
    }
    
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Item ID: ");
        String id = sc.next();
        System.out.println("Enter Item description: ");
        String desc = sc.next();
        System.out.println("Enter Item Quantity: ");
        int q = sc.nextInt();
        System.out.println("Enter Unit Price: ");
        double u = sc.nextDouble();
        
        InvoiceItem i1 = new InvoiceItem(id,desc,q,u);
        System.out.println("\nID : "+i1.getID()+"\nDesc : "+i1.getDesc()+"\nQuantity : "+i1.getQty()+"\nUnit Price : "+i1.getUnitPrice()+"\nTotal : "+i1.getTotal());
        System.out.println("\nEnter new Quantity:");
        q = sc.nextInt();
        System.out.println("Enter new Unit Price: ");
        u = sc.nextDouble();
        i1.setQty(q);
        i1.setUnitPrice(u);
        System.out.println("\nNew Quantity : "+i1.getQty()+"\nNew Unit Price : "+i1.getUnitPrice()+"\nNew Total : "+i1.getTotal());
        System.out.println("\nItem Details : "+i1.toString());
        
     }
}