import java.util.*;

public class KeyboardScanner{
    private int x;
    private double y;
    private String name;
    public KeyboardScanner(int x, double y, String name)
    {
        this.x =x;
        this.y = y;
        this.name = name;
    }
    public void display()
    {
        System.out.println("Hi! "+this.name+", the sum of "+this.x+" and "+this.y+" is "+(this.x+this.y));
    }
    
     public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        double y = sc.nextDouble();
        String name = sc.next();
        KeyboardScanner k1 = new KeyboardScanner(x,y,name);
        k1.display();
     }
}