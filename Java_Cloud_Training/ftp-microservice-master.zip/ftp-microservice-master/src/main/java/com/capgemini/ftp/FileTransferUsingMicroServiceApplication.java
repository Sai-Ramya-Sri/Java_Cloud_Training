package com.capgemini.ftp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileTransferUsingMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileTransferUsingMicroServiceApplication.class, args);
	}
}
